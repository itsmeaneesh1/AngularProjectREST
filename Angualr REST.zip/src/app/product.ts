export class Product {

    prodid:number|undefined;
    prodname:string|undefined;
    price:number|undefined;
    category:string|undefined;

    
        
  
}
